// --- local.js --- //



function animateOptionSelection(element) {
    let selectedListItem = element.closest('li');
    if (selectedListItem) {
        [...selectedListItem.parentNode.children].filter(el => {
            el !== selectedListItem ?
                el.classList.add('disabled') :
                el.classList.add('selected')
        });
    }
}

function eventOnGpiQuestions(element, value, isLastCalculation, nextQuestion) {

    let gpiQuestionDiv = element.closest('[data-gpi-index]');
    let gpiIndex = nextQuestion ? nextQuestion : gpiQuestionDiv.dataset.gpiIndex;
    console.log({ gpiIndex, nextQuestion });

    let gpiQuestion = element.closest(".gpi-question");
    let questionData = gpiAlgorithm.allQuestions[gpiIndex];
    let optionValue = value >= 0 ? value : element.getAttribute("value");

    if (nextQuestion) {
        gpiQuestion.classList.remove("gpi-active");
        gpiQuestion.nextElementSibling.nextElementSibling.nextElementSibling.classList.add("gpi-active");
        if (gpiQuestion.nextElementSibling.dataset.gpiKey === "swipe") {
            let togglerOptionElement = document.querySelector(".toggle-option-content");
            runToggleOptionSelected(togglerOptionElement);
        }
    }
    // next question
    else if (gpiQuestion.nextElementSibling) {
        gpiAlgorithm.calculateGpi(questionData.calculations, optionValue);
        setTimeout(() => {
            gpiQuestion.classList.remove("gpi-active");
            gpiQuestion.nextElementSibling.classList.add("gpi-active");
            if (gpiQuestion.nextElementSibling.dataset.gpiKey === "swipe") {
                let togglerOptionElement = document.querySelector(".toggle-option-content");
                runToggleOptionSelected(togglerOptionElement);
            }
        }, 1000);
    } else if (isLastCalculation === true) {
        // no need to calculate further 
        gpiAlgorithm.calculateGpi(questionData.calculations, optionValue, true);

        setTimeout(() => {
            gpiAlgorithm.setProfileType();
            com.haleon.mt.gotoSlide("IN_SURVEY_2025_IN1.0_V1.0_003", "IN_SURVEY_2025_IN1.0_V1.0_MAIN");
        }, 500);
    }
}

function generateGpiQuestions(data, qIndex) {
    let templateContent = `
        <div class="gpi-question ${qIndex === 0 ? 'gpi-active' : ''}" 
         data-gpi-index="${qIndex}" data-gpi-key="${data.key}">

            <div class="full-absolute z-index-n10">
                ${qIndex !== 9 ? `<div class="bg-box-blocks-1">
                    <div class="bg-area-1-1"></div>
                    <div class="bg-area-1-2"></div>
                </div>` : `
                <div class="bg-box-blocks-2">
                    <div class="bg-area-2-1"></div>
                    <div class="bg-area-2-2"></div>
                </div>`}
            </div>

            ${data.question ? `<h3 class="gpi-question-heading ${data.isInternalQuestions ? 'gpi-align-heading' : ''}">
                <span>
                    <span>${qIndex + 1}.</span>
                    <span>${data.question}</span>
                </span>
            </h3>` : ``}

            ${data.showParaNote === true ? `<p class="gpi-para-note">
                <span>*</span><span>${data.paraNote}</span>
            </p>` : ``}

            ${data.isInput === true ? optionsInInput(data) : ''}

            ${data.isMultiSelect === true ? optionsInMultiSelect(data) : ''}
            
            ${data.isOptionsInDropdown === true ? optionsInDropdown(data) : ''}

            ${data.isOptionsInTextFormat === true ? optionsInTextFormat(data) : ''}

            ${data.isSelectFeel === true ? selectFeelInOption(data) : ''}
            
            ${data.isUiToggleOptions === true ? isUiToggleOptions(data) : ''}
            

            ${data.isInternalQuestions ? multiQuestionOptions(data) : ""}
            
        </div>
    `;

    return templateContent;
}

function optionsInDropdown({ id, key, options }) {
    return `<select id="options-in-dropdown">
            ${options.reduce((acc, option, i) => {
        return acc + `<option value="${option.label}">${option.label}</option>`
    }, "<option disabled value='None' selected>None</option>")}
    </select>`
}

function optionsInInput({ id, key, options, isLastQuestion }) {
    return `${options.reduce((acc, option, i) => {
        return acc + `<div class="web-input-parent"><input class="gpi-input-response web-input" placeholder="${option.label}" /></div>`
    }, "")}<button class="gpi-mss">${isLastQuestion ? 'Submit' : 'Next'}</button>`
}

function optionsInMultiSelect({ id, key, options }) {
    if (options && options.length) {
        return `<ul class="gpi-${key}-list">
            ${options.reduce((acc, option, i) => {
            return acc + `
                    <li>
                        <span class="gpi-border-left"></span>
                        <input 
                            type="checkbox" 
                            data-gpi-checkbox-input 
                            id="${id}-${option.id}" 
                            name="checkbox-${id}" 
                            value="${option.value}" 
                        />
                        <label for="${id}-${option.id}">
                            ${option.label}
                        </label>
                        <span class="gpi-border-right"></span>
                    </li>
                `;
        }, "")}
        </ul><button class="gpi-mss">Next</button>`;
    } else {
        return "";
    }
}

function optionsInTextFormat({ id, key, options }) {
    if (options && options.length) {
        return `<ul class="gpi-${key}-list">
            ${options.reduce((acc, option, i) => {
            return acc + `
                    <li>
                        <span class="gpi-border-left"></span>
                        <input 
                            type="radio" 
                            data-gpi-radio-input 
                            id="${id}-${option.id}" 
                            name="radio-${id}" 
                            value="${option.value}" 
                        />
                        <label for="${id}-${option.id}">
                            ${option.label}
                        </label>
                        <span class="gpi-border-right"></span>
                    </li>
                `;
        }, "")}
        </ul>`;
    } else {
        return "";
    }
}

function selectFeelInOption({ id, key, options }) {
    if (options && options.length) {

        return `
        <div class="gpi-${key}-block">
            <div class="gpi-${key}-range-line"></div>
            <ul class="gpi-${key}-select">
                ${options.reduce((acc, option, i) => {
            return acc + `
                        <li data-gpi-option="${option.value}">
                           <img class="gpi-${key}-image" src="../shared/media/images/${option.image}.png" alt="${option.label}" />
                           <div class="gpi-${key}-line"></div>
                            <span>${option.label}</span>
                        </li>
                    `;
        }, "")}
            </ul>
        </div>`;

    } else {
        return "";
    }
}

function isUiToggleOptions(data) {
    return `
        <div class="toggle-option-content" data-toggle-swipe>
            <div class="option-label option-label-left">
                <span>${data.optionOne.label}</span>
            </div>
            <div class="toggler-arrows-icon noSwipe">
                <img src="../shared/media/images/arrow-white-left.png" alt="arrow left" />
                <img src="../shared/media/images/arrow-white-right.png" alt="arrow right" />
                <span class="toggler-icon-space"></span>
            </div>
            <div class="option-label option-label-right">
                <span>${data.optionTwo.label}</span>
            </div>
        </div>
    `;
}

function multiQuestionOptions(data) {
    let internalOptionsImage = function (id, calculate) {
        return data.defaultInternalOptions.reduce((acc, option, i) => {
            return acc + `
                <li 
                class="gpi-option-image-multi" 
                data-gpi-option-value="${option.value}" 
                ${calculate === true ? `data-gpi-calculate` : ""}>
                    <img src="../shared/media/images/${option.image}.png" alt="${option.label}" />
                </li>
            `
        }, "");
    };
    let internalOptionsDefault = function () {
        return data.defaultInternalOptions.reduce((acc, option, i) => {
            return acc + `
                <li>${option.label}</li>
            `
        }, "");
    };
    return `
    ${data.internalQuestions ? `
    <ul class="gpi-multi-checkbox-list">
        ${data.internalQuestions.reduce((acc, option, i) => {
        return acc + `
            <li class="gpi-question-internal" data-internal-index="${i}">
                <h4>
                    <span>${option.romanIndex}.</span>
                    <span>${option.question}</span>
                </h4>
                <ul ${data.internalQuestions.length - 1 === i ? `style="border-bottom: 0;"` : ``}>
                    ${option.isInternalOptions ?
                internalOptionsImage(option.id, option.isRequiredToCalculate) : ''}
                </ul>
            </li>`
    }, `
        <li>
            <ul class="gpi-checkbox-options">${internalOptionsDefault(data.id)}</ul>
        </li>
    `)}
    </ul>
    <button class="gpi-checkbox-submit" type="submit" disabled>Submit</button>
    ` : ""}`
}

function runToggleOptionSelected(togglerOptionElement) {
    let togglerArrowsIconElement = togglerOptionElement.querySelector(".toggler-arrows-icon");
    let optionLabelLeft = togglerOptionElement.querySelector(".option-label-left");
    let optionLabelRight = togglerOptionElement.querySelector(".option-label-right");
    let toggleSwipe = togglerOptionElement.dataset.toggleSwipe;

    let hammerTimeElement = new Hammer(togglerArrowsIconElement);

    function leftSwipe() {
        togglerOptionElement.dataset.toggleSwipe = toggleSwipe === 'right' ? '' : 'left';
        togglerOptionElement.dataset.gpiRadioInput = '1';
        setTimeout(() => eventOnGpiQuestions(togglerOptionElement, 1, null, "4"), 2500);

        com.haleon.mt.cstreamSurvey.push({
            Question_vod__c: togglerOptionElement.closest("[data-gpi-key]").querySelector(".gpi-question-heading span span:nth-child(2)").textContent,
            Answer_vod__c: "Yes"
        })
        console.log(com.haleon.mt.cstreamSurvey);
    }

    function rightSwipe() {
        togglerOptionElement.dataset.toggleSwipe = toggleSwipe === 'left' ? '' : 'right';
        togglerOptionElement.dataset.gpiRadioInput = '2';
        setTimeout(() => eventOnGpiQuestions(togglerOptionElement, 2), 2500);

        com.haleon.mt.cstreamSurvey.push({
            Question_vod__c: togglerOptionElement.closest("[data-gpi-key]").querySelector(".gpi-question-heading span span:nth-child(2)").textContent,
            Answer_vod__c: "No"
        })
        console.log(com.haleon.mt.cstreamSurvey);
    }

    hammerTimeElement.on('swipeleft swiperight', (event) => {
        if (event.type === 'swipeleft') leftSwipe();
        if (event.type === 'swiperight') rightSwipe();
    });

    togglerOptionElement.addEventListener('tap', (e) => {
        if (e.target === optionLabelLeft) leftSwipe();
        if (e.target === optionLabelRight) rightSwipe();
    });

}

async function renderQuestions() {
    let questionsContainer = document.querySelector(".gpi-questions-list");

    await (questionsContainer.innerHTML += gpiAlgorithm.allQuestions
        .reduce((acc, data, qIndex) => acc + generateGpiQuestions(data, qIndex), ""));

    function assignKeyMethod(key, callbackFn) {
        [...document.querySelectorAll(`[data-gpi-key="${key}"]`)].forEach(el => {
            el.addEventListener("click", callbackFn);
        });
    }

    assignKeyMethod("dropdown", (e) => {
        e.stopImmediatePropagation();

        if (e.target.querySelector('option:checked').value != "None") {
            animateOptionSelection(e.target);
            setTimeout(() => eventOnGpiQuestions(e.target), 1000);
            console.log(e.target.value);

            com.haleon.mt.cstreamSurvey.push({
                Question_vod__c: e.target.closest("[data-gpi-key]").querySelector(".gpi-question-heading span span:nth-child(2)").textContent,
                Answer_vod__c: e.target.value
            })
        }
    }, { capture: true });

    assignKeyMethod("input", (e) => {
        e.stopImmediatePropagation();
        var gpiKey = e.target.closest("[data-gpi-key]");
        if (!gpiKey.querySelector(".gpi-input-response").value) {
            return;
        }
        if (e.target.classList.contains("gpi-mss")) {
            if (e.target.innerText == "Submit") {
                console.log('submit');
                document.querySelector(".gpi-questions-list").innerHTML = `
                    <div class="survey-complete">Thank You</div>
                    <div id="home"></div>
                `;
                document.querySelector("#home").addEventListener(com.haleon.mt.releaseEvent, function () {
                    document.querySelector(".gpi-questions-list").innerHTML = "";
                    renderQuestions();
                })
            }
            animateOptionSelection(e.target);
            setTimeout(() => eventOnGpiQuestions(e.target), 1000);

            com.haleon.mt.cstreamSurvey.push({
                Question_vod__c: e.target.closest("[data-gpi-key]").querySelector(".gpi-question-heading span span:nth-child(2)").textContent,
                Answer_vod__c: gpiKey.querySelector(".gpi-input-response").value
            })
            console.log(com.haleon.mt.cstreamSurvey);
            e.target.setAttribute("disabled", "disabled");
        }
    }, { capture: true });
    let checkboxAnswers = [];
    assignKeyMethod("select", (e) => {
        e.stopImmediatePropagation();
        var gpiKey = e.target.closest("[data-gpi-key]");
        if (e.target.hasAttribute('data-gpi-radio-input')) {
            if (!e.target.value) {
                return;
            }
            animateOptionSelection(e.target);
            setTimeout(() => eventOnGpiQuestions(e.target), 1000);
            com.haleon.mt.cstreamSurvey.push({
                Question_vod__c: gpiKey.querySelector(".gpi-question-heading span span:nth-child(2)").textContent,
                Answer_vod__c: e.target.value
            })
        } else if (e.target.classList.contains("gpi-mss")) {
            if (checkboxAnswers.length === 0) {
                return;
            }
            animateOptionSelection(e.target);
            setTimeout(() => eventOnGpiQuestions(e.target), 1000);

            com.haleon.mt.cstreamSurvey.push({
                Question_vod__c: gpiKey.querySelector(".gpi-question-heading span span:nth-child(2)").textContent,
                Answer_vod__c: checkboxAnswers.length > 0 ? checkboxAnswers.join("|") : gpiKey.querySelector(".gpi-input-response").value
            })
            checkboxAnswers = [];
        } else if (e.target.hasAttribute('data-gpi-checkbox-input')) {
            e.target.closest("li").classList.add("selected");
            checkboxAnswers.push(e.target.closest("li").querySelector("label").textContent.trim());
        }
    }, { capture: true });

    assignKeyMethod("emotion", (e) => {
        e.stopImmediatePropagation();
        let element = e.target.hasAttribute('data-gpi-option') ? e.target : e.target.closest('[data-gpi-option]');
        animateOptionSelection(element);
        setTimeout(() => eventOnGpiQuestions(element, element.dataset.gpiOption), 3000);
    }, { capture: true });

    assignKeyMethod("feedback", (e) => {
        e.stopImmediatePropagation();

        if (e.target.hasAttribute("data-gpi-option-value")) {
            submitMultipleOptions(e.target)
        } else if (e.target.closest("[data-gpi-option-value]")) {
            submitMultipleOptions(e.target.closest("[data-gpi-option-value]"))
        }

        if (e.target.classList.contains("gpi-checkbox-submit")) {
            let dataLastQuestion = document.querySelector('[data-gpi-index="4"]');
            let gpiQuestionInternal = dataLastQuestion.querySelector('[data-internal-index="5"]');

            eventOnGpiQuestions(
                gpiQuestionInternal,
                gpiQuestionInternal.querySelector('.select-active').dataset.gpiOptionValue,
                true
            );
        }

    }, { capture: true });

}

function submitMultipleOptions(element) {
    [...element.parentNode.children].map(el => {
        el !== element ?
            el.classList.remove('select-active') :
            el.classList.add('select-active')
    });
    // if (element.hasAttribute("data-gpi-calculate") === false) {
    //     return;
    // } 
    let multiCheckBoxList = document.querySelector(".gpi-multi-checkbox-list");
    let activeElementLength = multiCheckBoxList.querySelectorAll(".select-active").length;
    let internalQuestionLength = document.querySelectorAll(".gpi-question-internal").length;
    // console.log(activeElementLength , internalQuestionLength);
    if (activeElementLength === internalQuestionLength) {
        document.querySelector(".gpi-checkbox-submit").removeAttribute('disabled');
    }
}

renderQuestions();

alert("Checking checking");
function isIPad() {
    const ua = navigator.userAgent;
    // return /iPad|Macintosh/i.test(ua) && 'ontouchend' in document;
    return true;
}

// if (isIPad() && window.visualViewport) {
//     let originalScrollPosition = 0;
//     let activeInput = null;
//     let viewportHeight = window.visualViewport.height;

//     // Track viewport changes
//     // window.visualViewport.addEventListener('resize', function () {
//     //     alert("Viewport changes input will also will change");
//     //     if (!activeInput) return;

//     //     // Keyboard likely opened (viewport shrunk)
//     //     if (this.height < viewportHeight) {
//     //         originalScrollPosition = window.pageYOffset;
//     //         const inputRect = activeInput.getBoundingClientRect();
//     //         const scrollToPosition = inputRect.top + window.pageYOffset - 100;

//     //         window.scrollTo({
//     //             top: scrollToPosition,
//     //             behavior: 'smooth'
//     //         });
//     //     }
//     //     // Keyboard likely closed (viewport restored)
//     //     else if (this.height >= viewportHeight) {
//     //         window.scrollTo({
//     //             top: originalScrollPosition,
//     //             behavior: 'smooth'
//     //         });
//     //         activeInput = null;
//     //     }

//     //     viewportHeight = this.height;
//     // });

//     // Track active input
//     document.addEventListener('focusin', function (e) {
//         if (e.target.matches('input, textarea, [contenteditable]')) {
//             alert("Robot");
//             activeInput = e.target;
//         }
//     });
// }


// if (isIPad()) {
//     // const webInput = document.querySelectorAll(".web-input");

//     // Track active input
//     // webInput.forEach((inputEle) => {
//         document.addEventListener('focusin', function (e) {
//             const webInputParent = document.querySelectorAll("web-input-parent");
//             // if (e.target.matches('input, textarea, [contenteditable]')) {
//             //     alert("Robot In");
//             //     // activeInput = e.target;
//             //     e.parentNode.classList.add("input-go-top");
//             // } else {
//             //     alert("Robot Out");
//             //     e.parentNode.classList.remove("input-go-top");
//             // }

//             if (e.target.matches('input')) {
//                 alert("Robot In");
//                 // activeInput = e.target;
//                 webInputParent.forEach((e)=>{
//                     e.classList.add("input-go-top");
//                 })
//             } 
//             // else {
//             //     alert("Robot Out");
//             //     webInputParent.classList.remove("input-go-top");
//             // }
//         });
//     // })

// }


if (isIPad()) {
document.addEventListener('focusin', function (e) {
    const webInputParent = document.querySelectorAll("web-input-parent");
    // if (e.target.matches('input, textarea, [contenteditable]')) {
    //     alert("Robot In");
    //     // activeInput = e.target;
    //     e.parentNode.classList.add("input-go-top");
    // } else {
    //     alert("Robot Out");
    //     e.parentNode.classList.remove("input-go-top");
    // }

    if (e.target.matches('input')) {
        alert("Robot In");
            e.parentNode.classList.add("input-go-top");
    } 
    // else {
    //     alert("Robot Out");
    //     webInputParent.classList.remove("input-go-top");
    // }
});
}