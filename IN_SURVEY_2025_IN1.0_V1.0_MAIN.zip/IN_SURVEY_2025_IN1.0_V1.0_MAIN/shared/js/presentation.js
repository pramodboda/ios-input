/**********************************************************/
/* HALEON Veeva Master Template - Presentation Functionality */
/**********************************************************/
/* File version              1.8                 */
/* Last modified             05/08/2022           */
/* Last modified by          Design Center Consumer */
/**********************************************************/

// --- CUSTOM TO THIS PRESENTATION --- //

$(document).ready(function () {
    document.title = "HALEON Master Template";
    if ($("#setAnimations").length) {
        // --- SET TEXT ON HOME PAGE BUTTON --- //
        if (window.sessionStorage.getItem('mthaleonAnimations') === '1') {
            $('#setAnimations').text("Animations are On");
        } else {
            $('#setAnimations').text("Animations are Off");
        }

        com.haleon.mt.bindInteraction("#setAnimations", "tap", {}, function () {
            if (window.sessionStorage.getItem('mthaleonAnimations') === '1') {
                window.sessionStorage.setItem('mthaleonAnimations', '0');
                $('#setAnimations').text("Animations are Off");
                com.haleon.mt.debug("Animations are Off");
            } else {
                window.sessionStorage.setItem('mthaleonAnimations', '1');
                $('#setAnimations').text("Animations are On");
                com.haleon.mt.debug("Animations are On");
            }
        });
    }

});

/* Page 20 */

let gpiAlgorithm = {
    allQuestions: [
        {
            id: "q1",
            key: "dropdown",
            question: "Please select the brand as per your team?",
            paraNote: "This could be anything from taking a pain relief medication to doing specific stretches targeting the pain or resting in an attempt to relieve your pain.",
            showParaNote: false,
            isOptionsInDropdown: true,
            options: [{
                    id: "o1",
                    label: "Otrivin Breathe Clean",
                    value: "1"
                },
                {
                    id: "o2",
                    label: "Otrivin Natural",
                    value: "2"
                },
                {
                    id: "o3",
                    label: "Sensodyne",
                    value: "3"
                },
                {
                    id: "o4",
                    label: "Otrivin First Clean Then Treat",
                    value: "4"
                },
                {
                    id: "o5",
                    label: "Otrivin Heartland",
                    value: "5"
                }
            ],
            calculations: {
                intense: 3.831022,
                stoic: 4.310265,
                silent: 5.065163,
                staunch: 3.889423,
                burdened: 8.401686,
                // unclassified: 10.34392
            },
            isRequiredToCalculate: false
        },
        {
            id: "q2",
            key: "swipe",
            question: "Call objective acheived?",
            isUiToggleOptions: true,
            optionOne: {
                id: "o1",
                label: "Yes",
                value: "1"
            },
            optionTwo: {
                id: "o2",
                label: "No",
                value: "2"
            },
            calculations: {
                intense: 6.554513,
                stoic: 10.51041,
                silent: 7.498127,
                staunch: 6.990709,
                burdened: 6.68127,
                // unclassified: 10.35189
            },
            isRequiredToCalculate: false
        },
        {
            id: "q3",
            key: "select",
            question: "If No, identify the barrier for conversion:",
            paraNote: "Please choose from the multiple options",
            showParaNote: true,
            isMultiSelect: true,
            isOptionsInTextFormat: false,
            options: [{
                id: "o1",
                label: "Efficacy of Haleon product vs current product used by HCP",
                value: "1"
            }, {
                id: "o2",
                label: "Safety of Haleon product vs current product used by HCP",
                value: "2"
            }, {
                id: "o3",
                label: "Patient convenience of Haleon product vs current product used by HCP",
                value: "3"
            }, {
                id: "o4",
                label: "Price of Haleon product vs current product used by HCP",
                value: "4"
            }, {
                id: "o5",
                label: "Support and resources provided by Haleon",
                value: "4"
            }, {
                id: "o6",
                label: "PAwareness and familiarity with Haleon product",
                value: "4"
            }],
            calculations: {
                intense: 3.012258,
                stoic: 6.149346,
                silent: 4.472801,
                staunch: 4.899882,
                burdened: 4.707676,
                // unclassified: 5.989769
            },
            isRequiredToCalculate: false
        },
        {
            id: "q4",
            key: "input",
            question: "If there are any other barrier which is not mentioned in Q3, please mention here",
            paraNote: "",
            isInput: true,
            options: [{
                id: "o1",
                label: "Your feedback here in an input",
                value: "1"
            }],
            calculations: {
                intense: 3.012258,
                stoic: 6.149346,
                silent: 4.472801,
                staunch: 4.899882,
                burdened: 4.707676,
                // unclassified: 5.989769
            },
            isRequiredToCalculate: false
        },
        {
            id: "q5",
            key: "select",
            question: "If Yes, Call Objective Acheived, list the result:",
            paraNote: "Please choose from one of the options",
            showParaNote: true,
            isOptionsInTextFormat: true,
            options: [{
                    id: "o1",
                    label: "Commmitment to prescribe",
                    value: "Commmitment to prescribe"
                },
                {
                    id: "o2",
                    label: "Agreed for incremental prescription for targeted Haleon Product",
                    value: "Agreed for incremental prescription for targeted Haleon Product"
                },
                {
                    id: "o3",
                    label: "Received dispensing Order",
                    value: "Received dispensing Order"
                },
                {
                    id: "o4",
                    label: "Feedback on product performance",
                    value: "Feedback on product performance"
                },
                {
                    id: "o5",
                    label: "Interest in future collaborations or partnerships",
                    value: "Interest in future collaborations or partnerships"
                }
            ],
            calculations: {
                intense: 3.831022,
                stoic: 4.310265,
                silent: 5.065163,
                staunch: 3.889423,
                burdened: 8.401686,
                // unclassified: 10.34392
            },
            isRequiredToCalculate: false
        },
        {
            id: "q6",
            key: "input",
            question: "If there are any other results apart from mentioned in Q4, please mention here",
            paraNote: "",
            isInput: true,
            options: [{
                id: "o1",
                label: "Your feedback here in an input",
                value: "1"
            }],
            calculations: {
                intense: 3.012258,
                stoic: 6.149346,
                silent: 4.472801,
                staunch: 4.899882,
                burdened: 4.707676,
                // unclassified: 5.989769
            },
            isRequiredToCalculate: false
        },
        {
            id: "q7",
            key: "select",
            question: "Next call action",
            paraNote: "Please choose from the multiple options",
            showParaNote: true,
            isMultiSelect: true,
            isOptionsInTextFormat: false,
            options: [{
                id: "o1",
                label: "Follow up via RCPA for prescrription",
                value: "1"
            }, {
                id: "o2",
                label: "Follow up via RCPA for incremental prescrription",
                value: "2"
            }, {
                id: "o3",
                label: "Ensure supplies by co-ordinating with GT / PWD or ALC",
                value: "3"
            }, {
                id: "o4",
                label: "Collect Testimonials",
                value: "4"
            }, {
                id: "o5",
                label: "Evaluate Engagement in RTMs, LnLs or Camp",
                value: "4"
            }],
            calculations: {
                intense: 3.012258,
                stoic: 6.149346,
                silent: 4.472801,
                staunch: 4.899882,
                burdened: 4.707676,
                // unclassified: 5.989769
            },
            isRequiredToCalculate: false
        }, {
            id: "q8",
            key: "input",
            question: "Any Other comments ?",
            paraNote: "",
            isInput: true,
            options: [{
                id: "o1",
                label: "Add your comment here",
                value: "1"
            }],
            calculations: {
                intense: 3.012258,
                stoic: 6.149346,
                silent: 4.472801,
                staunch: 4.899882,
                burdened: 4.707676,
                // unclassified: 5.989769
            },
            isRequiredToCalculate: false,
            isLastCalculation: true,
            isLastQuestion: true
        },
        // {
        //     id: "q8",
        //     key: "emotion",
        //     question: "Which of the following best describes how your pain made you feel?",
        //     isSelectFeel: true,
        //     options: [{
        //         id: "o1",
        //         label: "Extremely anxious",
        //         image: "extremely-anxious",
        //         value: "1"
        //     }, {
        //         id: "o2",
        //         label: "Very anxious",
        //         image: "very-anxious",
        //         value: "2"
        //     }, {
        //         id: "o3",
        //         label: "Quite anxious",
        //         image: "quite-anxious",
        //         value: "3"
        //     }, {
        //         id: "o4",
        //         label: "Worried but not anxious",
        //         image: "worried-but-not-anxious",
        //         value: "4"
        //     }, {
        //         id: "o5",
        //         label: "A little worried",
        //         image: "a-little-worried",
        //         value: "5"
        //     }, {
        //         id: "o6",
        //         label: "Not worried at all",
        //         image: "not-worried-at-all",
        //         value: "6"
        //     }],
        //     calculations: {
        //         intense: 3.013558,
        //         stoic: 9.078235,
        //         silent: 5.287635,
        //         staunch: 6.70982,
        //         burdened: 5.449941,
        //         // unclassified: 8.844497
        //     },
        //     isRequiredToCalculate: true
        // },
        // {
        //     id: "q9",
        //     key: "feedback",
        //     question: "Do you wish you had better control over your pain?",
        //     isInternalQuestions: true,
        //     internalQuestions: [
        //         {
        //             id: "q1",
        //             romanIndex: 'I',
        //             question: "I wish public authorities did more to help people like me manage their pain",
        //             isRequiredToCalculate: false,
        //             isInternalOptions: true
        //         }, {
        //             id: "q2",
        //             romanIndex: 'II',
        //             question: "I wish doctors/specialists took pain like mine more seriously",
        //             isRequiredToCalculate: false,
        //             isInternalOptions: true
        //         }, {
        //             id: "q3",
        //             romanIndex: 'III',
        //             question: "I wish pain was better accepted in our society",
        //             isRequiredToCalculate: false,
        //             isInternalOptions: true
        //         }, {
        //             id: "q4",
        //             romanIndex: 'IV',
        //             question: "I wish more could be done to help manage everyday pain",
        //             isRequiredToCalculate: false,
        //             isInternalOptions: true
        //         }, {
        //             id: "q5",
        //             romanIndex: 'V',
        //             question: "I wish my doctor would be more supportive when it comes to the impact of my pain on my life",
        //             isRequiredToCalculate: false,
        //             isInternalOptions: true
        //         }, 
        //         {
        //             id: "q6",
        //             romanIndex: 'VI',
        //             question: "I wish I could control my pain better",
        //             isRequiredToCalculate: true,
        //             isInternalOptions: true
        //         }
        //     ],
        //     defaultInternalOptions: [{
        //             id: "o1",
        //             label: "Completely disagree",
        //             image: "completely-disagree",
        //             value: "1"
        //         },
        //         {
        //             id: "o2",
        //             label: "Somewhat disagree",
        //             image: "somewhat-disagree",
        //             value: "2"
        //         },
        //         {
        //             id: "o3",
        //             label: "Neither agree nor disagree",
        //             image: "neither-agree-nor-disagree",
        //             value: "3"
        //         },
        //         {
        //             id: "o4",
        //             label: "Somewhat agree",
        //             image: "somewhat-agree",
        //             value: "4"
        //         },
        //         {
        //             id: "o5",
        //             label: "Completely agree",
        //             image: "completely-agree",
        //             value: "5"
        //         }
        //     ],
        //     calculations: {
        //         intense: 2.459102,
        //         stoic: 4.292737,
        //         silent: 5.827427,
        //         staunch: 2.355605,
        //         burdened: 2.649132,
        //         // unclassified: 4.465583
        //     }
        // }
    ],
    constant: {
        intense: -13.3979,
        stoic: -53.2005,
        silent: -33.2376,
        staunch: -28.7311,
        burdened: -34.5912,
        // unclassified: -69.0408 // Not required to client as of now
    },
    profile: {
        intense: "Pain is out of control",
        stoic: "Pain is life",
        silent: "What pain?",
        staunch: "Pain is a signal",
        burdened: "Pain is scary",
        // unclassified: "Does not treat Pain" // Not required to client as of now
    },
    videos: {
        intense: {
            poster: "PAIN-IS-OUT-OF-CONTROL-ESZTER_V15.png",
            video: "PAIN IS OUT OF CONTROL - ESZTER_V15.mp4"
        },
        stoic: {
            poster: "PAIN-IS-LIFE-BEGUM_V15.png",
            video: "PAIN IS LIFE - BEGUM_V15.mp4"
        },
        silent: {
            poster: "WHAT-PAIN-SOURAV_V15.png",
            video: "WHAT PAIN - SOURAV_V15.mp4"
        },
        staunch: {
            poster: "PAIN-IS-A-SIGNAL-SEBASTIAN_V15.png",
            video: "PAIN IS A SIGNAL - SEBASTIAN_V15.mp4"
        },
        burdened: {
            poster: "PAIN-IS-SCARY-CAROL_V15.png",
            video: "PAIN IS SCARY - CAROL_V15.mp4"
        }
    },
    result: null,
    mathGpi: (calculations = {
        ...obj
    }, score) => {
        Object.keys(calculations).map((property, key) => {
            calculations[property] = parseFloat(calculations[property] * score);
        });
        return calculations;
    },
    sumGpi: (previous, current = {
        ...obj
    }) => {
        Object.keys(current).map((property, key) => {
            current[property] = parseFloat(current[property] + previous[property]);
        });
        return current;
    },
    calculateGpi: function (calculations, score, isCalculateConstant) {
        let mathResult = this.mathGpi(calculations, score);
        if (this.result !== null) this.result = this.sumGpi(this.result, mathResult);
        if (this.result === null) this.result = mathResult;
        if (isCalculateConstant === true) this.result = this.sumGpi(this.result, this.constant);
        console.log(this.result);
    },
    getMaxResultProperty: function ()  {
        if (this.result === null) return "";
        let maxVal = Math.max(...Object.values(this.result));
        let maxProp = Object.keys(this.result).find(key => this.result[key] === maxVal);
        console.log(this.result, maxProp);
        return maxProp;
    },
    setProfileType: function (profile) {
        let painProfile = profile ? profile : this.getMaxResultProperty();
        sessionStorage.setItem("GPI-PROFILE-ALGORITHM", painProfile);
    },
    getProfileType: function () {
        return sessionStorage.getItem("GPI-PROFILE-ALGORITHM");
    }
}
